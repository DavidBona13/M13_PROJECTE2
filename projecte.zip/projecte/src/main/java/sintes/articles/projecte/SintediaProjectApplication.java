package sintes.articles.projecte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SintediaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SintediaProjectApplication.class, args);
	}

}
