package com.sintedia.projectemongoback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjecteMongoBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjecteMongoBackApplication.class, args);
	}

}
